from django.urls import path
from django.conf.urls.static import static
from django.conf import settings


from . import views


urlpatterns = [
    path('follow/', views.follow_index,
         name='follow_index'),  # авторы, на которых подписан пользователь
    path('subscriptions/', views.Subscribe.as_view(),
         name='subscribe'),  # js добавление автора в подписки
    path('subscriptions/<int:author_of_recipe>/',
         views.Subscribe.as_view(),
         name='unsubscribe'),  # js удаление автора из подписок
]