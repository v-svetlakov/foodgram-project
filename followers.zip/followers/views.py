from django.shortcuts import render, get_object_or_404, redirect
from . models import Follow, User
from posts.models import Post
from django.core.paginator import Paginator
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.views.generic import View
from django.http import HttpResponse, JsonResponse

import json


@login_required
def follow_index(request):
    """Страница "Мои подписки" с рецептами авторов,
    на которых подписан текущий пользователь"""
    follow_index = True

    favorite_authors = request.user.follower.all()

    paginator = Paginator(favorite_authors, 9)
    page_number = request.GET.get('page')
    page = paginator.get_page(page_number)

    return render(request, 'myFollow.html', {
        'page': page,
        'paginator': paginator,
        'follow_index': follow_index, })


class Subscribe(View):
    """Работает с js, добавляет пользователя
    в "Мои подписки"/удаляет из него"""

    def post(self, request):
        author_id = json.loads(request.body).get('id')
        author = get_object_or_404(User, id=author_id)
        if request.user != author:
            Follow.objects.get_or_create(user=request.user, author=author)
            return JsonResponse({'success': 'true'})
        return JsonResponse({'success': 'false'})

    def delete(self, request, author_of_recipe):
        author = get_object_or_404(User, id=author_of_recipe)
        count, _ = Follow.objects.filter(
            user=request.user, author=author
            ).all().delete()
        return JsonResponse({'success': 'true' if count > 0 else 'false'})